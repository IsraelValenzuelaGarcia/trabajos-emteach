Estado = "Sinaloa"

Superficie_Kilometros_Cuadrados = 57365

Climas = "Calido", "subhúmedo", "semiseco"
Climas_Cadenas = str(Climas)

Temperatura_Media_Anual_Centigrados = 25.47
Temperatura = str(Temperatura_Media_Anual_Centigrados)

Precipitacion_anual_promedio_mm = 790.1

Poblacion_mujeres = 1532128

Poblacion_hombres = 1494815

Porcentaje_habitantes_culiacan = 33.15

Porcentaje_habitantes_mazatlan = 16.57

Poblacion_total_habitantes = 1532128 + 1494815
Poblacion_Cadena = str(Poblacion_total_habitantes)

print("La población total de habitantes es: " + Poblacion_Cadena  )

Porcentaje_total_poblacion = 33.15 + 16.57
Porcentaje_Cadena = str(Porcentaje_total_poblacion)

print("El porcentaje total de la población es: " + Porcentaje_Cadena)

print("La temperatura media anual en centigrados es de: " + Temperatura)

print("Los distintos climas que hay en Sinaloa son: " + Climas_Cadenas)